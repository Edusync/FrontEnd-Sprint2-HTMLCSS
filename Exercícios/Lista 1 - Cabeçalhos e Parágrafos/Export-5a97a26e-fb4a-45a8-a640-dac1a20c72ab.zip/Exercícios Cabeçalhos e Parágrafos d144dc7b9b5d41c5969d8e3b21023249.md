# Exercícios: Cabeçalhos e Parágrafos

1 - Crie uma página com layout abaixo:

![Untitled](Exerci%CC%81cios%20Cabec%CC%A7alhos%20e%20Para%CC%81grafos%20d144dc7b9b5d41c5969d8e3b21023249/Untitled.png)

2 - Crie uma página com layout abaixo:

![Untitled](Exerci%CC%81cios%20Cabec%CC%A7alhos%20e%20Para%CC%81grafos%20d144dc7b9b5d41c5969d8e3b21023249/Untitled%201.png)

3 - Crie uma página com layout abaixo:

![Untitled](Exerci%CC%81cios%20Cabec%CC%A7alhos%20e%20Para%CC%81grafos%20d144dc7b9b5d41c5969d8e3b21023249/Untitled%202.png)